package es.maestre.sqlitemvvm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import es.maestre.sqlitemvvm.data.Abogado
import es.maestre.sqlitemvvm.ui.theme.SQLiteMVVMTheme
import es.maestre.sqlitemvvm.viewmodel.AbogadoViewModel

class MainActivity : ComponentActivity() {
    private val viewmodel: AbogadoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SQLiteMVVMTheme {
                PantallaAbogados(viewmodel)
            }
        }
    }
}

@Composable
fun PantallaAbogados(viewModel: AbogadoViewModel) {
    //"data" es el LiveData del ViewModel con los abogados de la base de datos
    val abogados by viewModel.data.observeAsState(emptyList())

    Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
        LazyColumn(modifier = Modifier.padding(innerPadding)) {
            items(abogados) { abogado ->
                AbogadoCard(abogado)
            }
        }
    }
}

@Composable
fun AbogadoCard(abogado: Abogado) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp, horizontal = 16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = abogado.nombre,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Text(text = "Teléfono: ${abogado.telefono}")
            Text(text = "Especialidad: ${abogado.especialidad}")
            Text(text = "Biografía: ${abogado.biografia}")
        }
    }
}