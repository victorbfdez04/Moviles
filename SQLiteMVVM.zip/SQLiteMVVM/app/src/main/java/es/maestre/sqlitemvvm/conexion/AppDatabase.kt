package es.maestre.sqlitemvvm.conexion

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import es.maestre.sqlitemvvm.data.Abogado
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Abogado::class], version = 1)
abstract class AppDatabase : RoomDatabase() {

 abstract fun abogadoDAO(): AbogadoDAO

 companion object {
  @Volatile
  var INSTANCE: AppDatabase? = null

  fun getDatabase(context: Context): AppDatabase {
   return INSTANCE ?: synchronized(this) {
    val instance = Room.databaseBuilder(
     context.applicationContext,
     AppDatabase::class.java,
     "abogados.db3"
    )
     // Callback para poblar datos iniciales
     .addCallback(DatabaseCallback())
     .build()
    INSTANCE = instance
    instance
   }
  }
 }
}

private class DatabaseCallback : RoomDatabase.Callback() {

 override fun onCreate(db: SupportSQLiteDatabase) {
  super.onCreate(db)
  AppDatabase.INSTANCE?.let { database ->
   CoroutineScope(Dispatchers.IO).launch {
    populateDatabase(database.abogadoDAO())
   }
  }
 }

 private suspend fun populateDatabase(abogadoDAO: AbogadoDAO) {
  abogadoDAO.insert(
   Abogado(
    nombre = "Juan Pérez",
    telefono = "600123456",
    especialidad = "Penal",
    biografia = "Abogado penalista con 10 años de experiencia."
   )
  )
  abogadoDAO.insert(
   Abogado(
    nombre = "María Gómez",
    telefono = "611987654",
    especialidad = "Civil",
    biografia = "Especialista en derecho civil y de familia."
   )
  )
 }
}